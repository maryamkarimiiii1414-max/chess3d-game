package __PACKAGE__;

import android.app.Activity;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.util.concurrent.atomic.AtomicBoolean;

// Wildcards on purpose: the init listener / model classes live in one of these two packages.
import ir.tapsell.plus.*;
import ir.tapsell.plus.model.*;

/**
 * Thin Capacitor wrapper around the Tapsell Plus Android SDK.
 * JS side: window.Capacitor.Plugins.TapsellBridge
 *   initialize({key})                       -> resolves once the SDK is up
 *   requestAd({type, zoneId})               -> {responseId}   (type: rewarded | interstitial)
 *   showAd({type, responseId})              -> {rewarded: bool}, resolves when the ad is closed
 *   showBanner({zoneId}) / hideBanner()     -> standard 320x50 banner under the WebView
 */
@CapacitorPlugin(name = "TapsellBridge")
public class TapsellBridge extends Plugin {
    private static final String TAG = "TapsellBridge";

    private boolean initStarted = false;
    private ViewGroup bannerBox = null;
    private String bannerResponseId = null;

    // ------------------------------------------------------------------ init
    @PluginMethod
    public void initialize(final PluginCall call) {
        final String key = call.getString("key");
        if (key == null || key.isEmpty()) {
            call.reject("missing key");
            return;
        }
        if (initStarted) {
            call.resolve();
            return;
        }
        initStarted = true;
        final Activity a = getActivity();
        final AtomicBoolean answered = new AtomicBoolean(false);

        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    TapsellPlus.setDebugMode(Log.DEBUG);
                    TapsellPlus.initialize(a, key, new TapsellPlusInitListener() {
                        @Override
                        public void onInitializeSuccess(AdNetworks adNetworks) {
                            Log.i(TAG, "init success: " + adNetworks);
                            if (answered.compareAndSet(false, true)) call.resolve();
                        }

                        @Override
                        public void onInitializeFailed(AdNetworks adNetworks, AdNetworkError error) {
                            // Called per ad network; one failing network must not block the others.
                            Log.e(TAG, "init failed: " + adNetworks + " / " + error);
                        }
                    });
                } catch (Throwable t) {
                    Log.e(TAG, "init exception", t);
                    initStarted = false;
                    if (answered.compareAndSet(false, true)) call.reject("init exception: " + t);
                }
            }
        });

        // Don't leave JS hanging if no init callback ever arrives.
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                if (answered.compareAndSet(false, true)) call.resolve();
            }
        }, 5000);
    }

    // --------------------------------------------------- request full-screen ad
    @PluginMethod
    public void requestAd(final PluginCall call) {
        final String type = call.getString("type", "rewarded");
        final String zone = call.getString("zoneId");
        if (zone == null || zone.isEmpty()) {
            call.reject("missing zoneId");
            return;
        }
        final Activity a = getActivity();
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    AdRequestCallback cb = new AdRequestCallback() {
                        @Override
                        public void response(TapsellPlusAdModel model) {
                            JSObject r = new JSObject();
                            r.put("responseId", model.getResponseId());
                            call.resolve(r);
                        }

                        @Override
                        public void error(String message) {
                            Log.e(TAG, "request error (" + type + "): " + message);
                            call.reject(message == null ? "request error" : message);
                        }
                    };
                    if ("interstitial".equals(type)) {
                        TapsellPlus.requestInterstitialAd(a, zone, cb);
                    } else {
                        TapsellPlus.requestRewardedVideoAd(a, zone, cb);
                    }
                } catch (Throwable t) {
                    Log.e(TAG, "request exception", t);
                    call.reject("request exception: " + t);
                }
            }
        });
    }

    // ----------------------------------------------------- show full-screen ad
    @PluginMethod
    public void showAd(final PluginCall call) {
        final String type = call.getString("type", "rewarded");
        final String responseId = call.getString("responseId");
        if (responseId == null || responseId.isEmpty()) {
            call.reject("missing responseId");
            return;
        }
        final Activity a = getActivity();
        final AtomicBoolean answered = new AtomicBoolean(false);
        final AtomicBoolean rewarded = new AtomicBoolean(false);

        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    AdShowListener l = new AdShowListener() {
                        @Override
                        public void onOpened(TapsellPlusAdModel model) {
                            Log.i(TAG, "ad opened (" + type + ")");
                        }

                        @Override
                        public void onRewarded(TapsellPlusAdModel model) {
                            rewarded.set(true);
                        }

                        @Override
                        public void onClosed(TapsellPlusAdModel model) {
                            if (answered.compareAndSet(false, true)) {
                                JSObject r = new JSObject();
                                r.put("rewarded", rewarded.get());
                                call.resolve(r);
                            }
                        }

                        @Override
                        public void onError(TapsellPlusErrorModel error) {
                            Log.e(TAG, "show error (" + type + "): " + error);
                            if (answered.compareAndSet(false, true)) call.reject("show error: " + error);
                        }
                    };
                    if ("interstitial".equals(type)) {
                        TapsellPlus.showInterstitialAd(a, responseId, l);
                    } else {
                        TapsellPlus.showRewardedVideoAd(a, responseId, l);
                    }
                } catch (Throwable t) {
                    Log.e(TAG, "show exception", t);
                    if (answered.compareAndSet(false, true)) call.reject("show exception: " + t);
                }
            }
        });
    }

    // ---------------------------------------------------------- standard banner
    /** Puts the WebView and a banner holder into a vertical LinearLayout so the banner never covers the game. */
    private void ensureBannerBox(Activity a) {
        if (bannerBox != null) return;
        View web = getBridge().getWebView();
        ViewGroup parent = (ViewGroup) web.getParent();
        int index = parent.indexOfChild(web);
        ViewGroup.LayoutParams webParams = web.getLayoutParams();
        parent.removeView(web);

        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.addView(web, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        RelativeLayout box = new RelativeLayout(a);
        box.setGravity(Gravity.CENTER);
        box.setBackgroundColor(Color.parseColor("#0B0C10"));
        root.addView(box, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        bannerBox = box;

        parent.addView(root, index, webParams);
    }

    @PluginMethod
    public void showBanner(final PluginCall call) {
        final String zone = call.getString("zoneId");
        if (zone == null || zone.isEmpty()) {
            call.reject("missing zoneId");
            return;
        }
        final Activity a = getActivity();
        final AtomicBoolean answered = new AtomicBoolean(false);

        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    ensureBannerBox(a);
                    TapsellPlus.requestStandardBannerAd(a, zone, TapsellPlusBannerType.BANNER_320x50,
                            new AdRequestCallback() {
                                @Override
                                public void response(TapsellPlusAdModel model) {
                                    final String id = model.getResponseId();
                                    a.runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            try {
                                                bannerResponseId = id;
                                                TapsellPlus.showStandardBannerAd(a, id, bannerBox,
                                                        new AdShowListener() {
                                                            @Override
                                                            public void onOpened(TapsellPlusAdModel m) {
                                                                if (answered.compareAndSet(false, true)) call.resolve();
                                                            }

                                                            @Override
                                                            public void onError(TapsellPlusErrorModel e) {
                                                                Log.e(TAG, "banner show error: " + e);
                                                                if (answered.compareAndSet(false, true)) call.reject("banner show error: " + e);
                                                            }
                                                        });
                                            } catch (Throwable t) {
                                                if (answered.compareAndSet(false, true)) call.reject("banner exception: " + t);
                                            }
                                        }
                                    });
                                }

                                @Override
                                public void error(String message) {
                                    Log.e(TAG, "banner request error: " + message);
                                    if (answered.compareAndSet(false, true)) call.reject(message == null ? "banner request error" : message);
                                }
                            });
                } catch (Throwable t) {
                    Log.e(TAG, "banner exception", t);
                    if (answered.compareAndSet(false, true)) call.reject("banner exception: " + t);
                }
            }
        });
    }

    @PluginMethod
    public void hideBanner(final PluginCall call) {
        final Activity a = getActivity();
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (bannerBox != null && bannerResponseId != null) {
                        TapsellPlus.destroyStandardBanner(a, bannerResponseId, bannerBox);
                        bannerResponseId = null;
                    }
                } catch (Throwable t) {
                    Log.e(TAG, "hide banner exception", t);
                }
                call.resolve();
            }
        });
    }
}
