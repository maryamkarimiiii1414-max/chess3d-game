#!/usr/bin/env python3
"""Runs after `npx cap add android`: adds the Tapsell Plus SDK + bridge plugin, launcher icons,
manifest entries and a versionCode that grows with every CI run."""
import json, os, pathlib, re, shutil, sys

root = pathlib.Path(__file__).resolve().parent.parent
android = root / "android"
cfg = json.loads((root / "capacitor.config.json").read_text(encoding="utf-8"))
app_id = cfg["appId"]

TAPSELL_VERSION = "2.2.9"

def fail(msg):
    print("PATCH ERROR:", msg)
    sys.exit(1)

if not android.exists():
    fail("android/ folder not found - run `npx cap add android` first")

# 1) Java sources (package name = appId)
pkg_dir = android / "app/src/main/java" / pathlib.Path(*app_id.split("."))
pkg_dir.mkdir(parents=True, exist_ok=True)
for name in ("MainActivity.java", "TapsellBridge.java"):
    src = (root / "native" / name).read_text(encoding="utf-8").replace("__PACKAGE__", app_id)
    (pkg_dir / name).write_text(src, encoding="utf-8")
print("java files ->", pkg_dir)

# 2) Gradle: Tapsell Plus SDK + version numbers
gradle = android / "app/build.gradle"
g = gradle.read_text(encoding="utf-8")
if "tapsell-plus-sdk-android" not in g:
    g, n = re.subn(r"^dependencies \{",
                   'dependencies {\n    implementation "ir.tapsell.plus:tapsell-plus-sdk-android:%s"' % TAPSELL_VERSION,
                   g, count=1, flags=re.M)
    if n != 1:
        fail("could not find the dependencies block in app/build.gradle")
run = int(os.environ.get("GITHUB_RUN_NUMBER", "1"))
g = re.sub(r"versionCode\s+\d+", "versionCode %d" % run, g)
g = re.sub(r'versionName\s+"[^"]*"', 'versionName "1.0.%d"' % run, g)
gradle.write_text(g, encoding="utf-8")
print("gradle patched, versionCode =", run)

# 3) Manifest: ad-id permission, network state, cleartext (some ad endpoints are plain http)
mf = android / "app/src/main/AndroidManifest.xml"
m = mf.read_text(encoding="utf-8")
perms = [
    "com.google.android.gms.permission.AD_ID",
    "android.permission.ACCESS_NETWORK_STATE",
]
for p in perms:
    if p not in m:
        m = m.replace("<application", '<uses-permission android:name="%s" />\n\n    <application' % p, 1)
if "usesCleartextTraffic" not in m:
    m = m.replace("<application", '<application\n        android:usesCleartextTraffic="true"', 1)
mf.write_text(m, encoding="utf-8")
print("manifest patched")

# 4) Launcher icons
res = android / "app/src/main/res"
overlay = root / "res-overlay"
for f in overlay.rglob("*"):
    if f.is_file():
        dest = res / f.relative_to(overlay)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(f, dest)
print("icons copied")
