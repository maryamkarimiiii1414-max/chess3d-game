# شطرنج سه‌بعدی – ساخت APK با تبلیغات تپسل

## ساخت APK
1. همه‌ی فایل‌ها و پوشه‌های این پروژه را (با همین ساختار) داخل ریپوی گیت‌هاب آپلود کن.
   حتماً پوشه‌ی `.github/workflows` هم آپلود شود.
2. در گیت‌هاب برو به **Actions ← Build Android APK ← Run workflow**
   (با هر push هم خودکار اجرا می‌شود).
3. بعد از حدود ۵ تا ۸ دقیقه، از پایین صفحه‌ی همان اجرا، فایل `chess3d-debug-apk` را دانلود کن.

## تنظیمات تپسل
داخل `www/index.html`، بخش `TapsellAds` (داخل فایل دنبال `var TapsellAds` بگرد):
- `APP_KEY` : کلید اپ از پنل تپسل
- `ZONE_REWARDED` / `ZONE_INTERSTITIAL` : شناسه‌ی تبلیغگاه‌های ویدیو جایزه‌ای و تمام‌صفحه
- `ZONE_BANNER` : شناسه‌ی بنر استاندارد (تا وقتی `null` است بنر نمایش داده نمی‌شود)

نام پکیج: `ir.username.chessgame` (در `capacitor.config.json`)، باید دقیقاً با پنل تپسل یکی باشد.

## APK امضاشده برای بازار (اختیاری)
در **Settings ← Secrets and variables ← Actions** این‌ها را بساز:
`KEYSTORE_BASE64`، `KEYSTORE_PASSWORD`، `KEY_ALIAS` (و در صورت تفاوت `KEY_PASSWORD`).
از آن به بعد خروجی `chess3d-release-apk` هم ساخته می‌شود.

## اگر تبلیغ نمایش داده نشد
- لاگ گوشی را با فیلتر `TapsellBridge` و `Tapsell` ببین (خطای درخواست تبلیغ آنجا چاپ می‌شود).
- بررسی کن اپ و تبلیغگاه‌ها در پنل تپسل فعال/تأیید شده باشند.
