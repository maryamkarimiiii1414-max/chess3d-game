package __PACKAGE__;

import android.app.Activity;
import android.util.Log;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.lang.reflect.Constructor;
import java.util.concurrent.atomic.AtomicBoolean;

import ir.cafebazaar.poolakey.Connection;
import ir.cafebazaar.poolakey.Payment;
import ir.cafebazaar.poolakey.config.PaymentConfiguration;
import ir.cafebazaar.poolakey.config.SecurityCheck;
import ir.cafebazaar.poolakey.request.PurchaseRequest;
import kotlin.Unit;

/**
 * Cafe Bazaar in-app purchase through the official Poolakey SDK.
 * JS side: window.Capacitor.Plugins.BazaarBilling.purchase({sku, key}) -> {ok: true}
 * Rejects with a readable message when the purchase does not happen (cancel / not installed / bad SKU ...).
 */
@CapacitorPlugin(name = "BazaarBilling")
public class BazaarBilling extends Plugin {
    private static final String TAG = "BazaarBilling";

    @PluginMethod
    public void purchase(final PluginCall call) {
        final String sku = call.getString("sku");
        final String key = call.getString("key");
        if (sku == null || sku.isEmpty()) {
            call.reject("missing sku");
            return;
        }
        final Activity a = getActivity();
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    start(a, call, sku, key);
                } catch (Throwable t) {
                    Log.e(TAG, "purchase exception", t);
                    call.reject("exception: " + t);
                }
            }
        });
    }

    private interface Finisher {
        void accept(boolean ok, String msg);
    }

    private static PurchaseRequest makeRequest(String sku) throws Exception {
        // Built by reflection so it works whichever Poolakey version adds/removes optional fields.
        for (Constructor<?> c : PurchaseRequest.class.getConstructors()) {
            Class<?>[] t = c.getParameterTypes();
            boolean allStrings = t.length >= 1 && t.length <= 3;
            for (Class<?> k : t) if (k != String.class) allStrings = false;
            if (allStrings) {
                Object[] args = new Object[t.length];
                args[0] = sku;
                if (t.length > 1) args[1] = "chess";
                return (PurchaseRequest) c.newInstance(args);
            }
        }
        throw new IllegalStateException("PurchaseRequest constructor not found");
    }

    private void start(final Activity a, final PluginCall call, final String sku, final String key) {
        final SecurityCheck check = (key == null || key.isEmpty())
                ? SecurityCheck.Disable.INSTANCE
                : new SecurityCheck.Enable(key);
        final Payment payment = new Payment(a.getApplicationContext(), new PaymentConfiguration(check));
        final Connection[] conn = new Connection[1];
        final AtomicBoolean done = new AtomicBoolean(false);

        final Runnable[] doPurchase = new Runnable[1];

        final Finisher finish = new Finisher() {
            @Override
            public void accept(boolean ok, String msg) {
                if (!done.compareAndSet(false, true)) return;
                try { if (conn[0] != null) conn[0].disconnect(); } catch (Throwable ignored) {}
                if (ok) {
                    JSObject r = new JSObject();
                    r.put("ok", true);
                    call.resolve(r);
                } else {
                    Log.e(TAG, "purchase not done: " + msg);
                    call.reject(msg);
                }
            }
        };

        doPurchase[0] = new Runnable() {
            @Override
            public void run() {
                try {
                    PurchaseRequest req = makeRequest(sku);
                    payment.purchaseProduct(a.getActivityResultRegistry(), req, cb -> {
                        cb.purchaseFlowBegan(() -> Unit.INSTANCE);
                        cb.failedToBeginFlow(t -> { finish.accept(false, "failedToBeginFlow: " + t); return Unit.INSTANCE; });
                        cb.purchaseSucceed(p -> { finish.accept(true, ""); return Unit.INSTANCE; });
                        cb.purchaseCanceled(() -> { finish.accept(false, "canceled"); return Unit.INSTANCE; });
                        cb.purchaseFailed(t -> { finish.accept(false, "purchaseFailed: " + t); return Unit.INSTANCE; });
                        return Unit.INSTANCE;
                    });
                } catch (Throwable t) {
                    finish.accept(false, "purchase exception: " + t);
                }
            }
        };

        conn[0] = payment.connect(cb -> {
            cb.connectionSucceed(() -> {
                // Non-consumable: if the user already owns it, just report success.
                try {
                    payment.getPurchasedProducts(q -> {
                        q.querySucceed(list -> {
                            if (String.valueOf(list).contains("productId=" + sku)) finish.accept(true, "");
                            else doPurchase[0].run();
                            return Unit.INSTANCE;
                        });
                        q.queryFailed(t -> { doPurchase[0].run(); return Unit.INSTANCE; });
                        return Unit.INSTANCE;
                    });
                } catch (Throwable t) {
                    doPurchase[0].run();
                }
                return Unit.INSTANCE;
            });
            cb.connectionFailed(t -> { finish.accept(false, "connectionFailed: " + t); return Unit.INSTANCE; });
            cb.disconnected(() -> Unit.INSTANCE);
            return Unit.INSTANCE;
        });
    }
}
